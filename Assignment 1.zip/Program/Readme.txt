To make the Excecutable; 
1.) use G++ -o main.exe main.cpp symbolTable.cpp 
2.) In CMD, run "Make" 